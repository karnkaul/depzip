auto main() -> int {}
