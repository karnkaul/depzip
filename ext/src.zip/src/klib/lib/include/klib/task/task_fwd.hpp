#pragma once

namespace klib::task {
class Task;
} // namespace klib::task
