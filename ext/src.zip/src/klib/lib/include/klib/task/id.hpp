#pragma once
#include <cstdint>

namespace klib::task {
enum struct Id : std::uint64_t { None = 0 };
} // namespace klib::task
